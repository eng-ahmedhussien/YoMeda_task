//
//  ViewController.swift
//  mealTask
//
//  Created by Ahmed Hussien on 18/01/2023.
//

import UIKit
import DropDown

class ViewController: UIViewController {
    
    @IBOutlet weak var mealPhotoCollection: UICollectionView!{
        didSet{
            mealPhotoCollection.delegate = self
            mealPhotoCollection.dataSource = self
//            let flowLayout = mealPhotoCollection as? UICollectionViewFlowLayout
//            flowLayout?.itemSize = CGSize(width: 100, height: 100)
//            flowLayout?.estimatedItemSize = .zero
//            flowLayout?.minimumInteritemSpacing = 1
        }
    }
    @IBOutlet weak var categoryButton: UIButton!
    @IBOutlet weak var mealName: UITextField!
    
    let dropDown = DropDown()
    var mealPhotos = [UIImage(systemName: "plus")]
    let mealNames = ["Tomato soup", "Mini burgers", "Onion rings", "Baked potato", "Salad"]
    let sizeArray = ["single","double"]
    let additionNames = ["Tomato soup", "Mini burgers", "Onion rings", "Baked potato", "Salad"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func categoryBPressed(_ sender: UIButton) {
        prepareDropDownList(data:mealNames,sender: sender )
    }
    @IBAction func sizeBPressed(_ sender: UIButton) {
        prepareDropDownList(data:sizeArray,sender: sender )
    }
    @IBAction func additionsBPressed(_ sender: UIButton) {
        prepareDropDownList(data:additionNames,sender: sender )
    }
    
    func prepareDropDownList(data:[String],sender:UIButton){
        sender.setImage(UIImage(named: "arrow-up"), for: .normal)
        dropDown.dataSource = data
        dropDown.anchorView = sender
        dropDown.bottomOffset = CGPoint(x: 0, y: sender.frame.size.height)
        dropDown.show()
        dropDown.selectionAction = { [weak self] (index: Int, item: String) in
            guard let _ = self else { return }
            sender.setTitle(item, for: .normal)
            sender.setImage(UIImage(named: "arrow-down"), for: .normal)
        }
        
    }
    
}
extension ViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mealPhotos.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MealPhotoCell.reuseID, for: indexPath) as! MealPhotoCell
        cell.mealPhoto.image = mealPhotos[indexPath.row]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//
//        showConfirmAlert(title: "Warning", message: "are you sure to delete") { answer in
//            if(answer){
//                self.mealPhotos.remove(at: indexPath.item)
//                self.mealPhotoCollection.deleteItems(at: [indexPath])
//                self.mealPhotoCollection.reloadData()
//            }
//
//        }
        if(indexPath.row == 0){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        }
    }
}


