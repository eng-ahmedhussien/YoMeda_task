//
//  MealPhotoCell.swift
//  mealTask
//
//  Created by Ahmed Hussien on 19/01/2023.
//

import UIKit

class MealPhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var mealPhoto: UIImageView!
    static let reuseID = String(describing: MealPhotoCell.self)
    
}

